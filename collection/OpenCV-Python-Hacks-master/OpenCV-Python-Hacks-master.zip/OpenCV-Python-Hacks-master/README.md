OpenCV-Python-Hacks
===================

Python Kalman filter, object tracking, etc. in OpenCV
